﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopQuanAo
{
    public class CTHD
    {
        private int MaHD;

        public int MAHD
        {
            get { return MaHD; }
            set { MaHD = value; }
        }
        private int MaSP;

        public int MASP
        {
            get { return MaSP; }
            set { MaSP = value; }
        }
        private int MaSize;

        public int MASIZE
        {
            get { return MaSize; }
            set { MaSize = value; }
        }
        private int SoLuong;

        public int SOLUONG
        {
            get { return SoLuong; }
            set { SoLuong = value; }
        }
        private int DonGia;

        public int DONGIA
        {
            get { return DonGia; }
            set { DonGia = value; }
        }

    }
}