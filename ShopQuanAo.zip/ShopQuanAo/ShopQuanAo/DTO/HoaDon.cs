﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopQuanAo
{
    public class HoaDon
    {
        private int MaHD;

        public int MAHD
        {
            get { return MaHD; }
            set { MaHD = value; }
        }

        private string NgayLapHD;

        public string NGAYLAPHD
        {
            get { return NgayLapHD; }
            set { NgayLapHD = value; }
        }
        private string NgayGiaoHang;

        public string NGAYGIAOHANG
        {
            get { return NgayGiaoHang; }
            set { NgayGiaoHang = value; }
        }
        private string DiaChiGiaoHang;

        public string DIACHIGIAOHANG
        {
            get { return DiaChiGiaoHang; }
            set { DiaChiGiaoHang = value; }
        }
        private int MaKH;

        public int MAKH
        {
            get { return MaKH; }
            set { MaKH = value; }
        }
        private bool TrangThai;

        public bool TRANGTHAI
        {
            get { return TrangThai; }
            set { TrangThai = value; }
        }
        private string HoTen;

        public string HOTEN
        {
            get { return HoTen; }
            set { HoTen = value; }
        }





    }
}